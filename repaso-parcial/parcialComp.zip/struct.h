//
// Created by agutierrez on 7/19/23.
//

#ifndef ALGORITMOS_2023_STRUCT_H
#define ALGORITMOS_2023_STRUCT_H

struct Proovedores {
    int cod_prod;
    char tipo_prod;
    int cpe;
};
struct ProovedoresA {
    int cod_prod;
    int cpe;
};

#endif //ALGORITMOS_2023_STRUCT_H
